<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link href="C/xampp/htdocs/PHP/Day3/aswan/bootstrap/bootstrap.css" rel="stylesheet" />
		<link href="C/xampp/htdocs/PHP/Day3/aswan/bootstrap/bootstrap-theme.css" rel="stylesheet" />



</head>
<body>


<h1>Hagar</h1>

                <div class="navbar-nav links">
                    <a href="/myname">Myname</a>
                    <a href="/myfather">Myfather</a>
                    <a href="/mygrand">Mygrandfather</a>
                   
                </div>





</body>
</html>

   
<?php /**PATH C:\Laravel\blog\resources\views/menu.blade.php ENDPATH**/ ?>
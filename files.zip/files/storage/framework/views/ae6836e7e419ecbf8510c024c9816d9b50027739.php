<!Doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="css/Mynav.css">

    <link rel="stylesheet" href="css/linearicons.css" type="text/css">
        <title>Nubian House</title>

</head>
<body>


<?php if($errors->any()): ?>
    <p style="color: red"><?php echo e($errors->first()); ?></p>
<?php endif; ?>

<!--All-->
<div class="main">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#" style="font-family: Curlz MT;">Nubian</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="/index">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/about">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/room">Rooms</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/restaurant">Restaurant</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/journey">Journey</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/gallery">Gallery</a>
                </li>











                <li class="nav-item">
                    <a class="nav-link" href="/contact">Contact Us</a>
                </li>
            </ul>


            <div class="login form-inline my-2 my-lg-0">

                <?php if(auth()->guard()->guest()): ?>
                        <div class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </div>
                    <?php if(Route::has('register')): ?>
                        &nbsp;&nbsp;&nbsp;
                        <div class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <?php if(auth()->user()->isAdmin()): ?>
                &nbsp;&nbsp;
                        <a href="/admin">Go To Tables</a>
                    <?php endif; ?>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item"  href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>

                    </div>
                    </div>
                <?php endif; ?>




                &nbsp;&nbsp;&nbsp;&nbsp;

                <img src="image/placeholder.png" alt="">
                &nbsp;&nbsp;&nbsp;
                <span style="color: white">Gharb Suhail,<br/> Aswan ,Eg</span>

            </div>

        </div>
    </nav>
</div>
<!---->

<?php echo $__env->yieldContent('content'); ?>



<!-- Footer Section Begin -->
<footer class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-logo">
                    <a href="#">Nubian</a>
                </div><br>
            </div>
        </div>
        <div class="row pb-50">
            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget">
                    <h5>Location</h5>
                    <div class="widget-text">
                        <i class="lnr lnr-map-marker"></i>
                        <p>1525 Boring Lane, <br />Los Angeles, CA</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget">
                    <h5>Reception</h5>
                    <div class="widget-text">
                        <i class="lnr lnr-phone-handset"></i>
                        <p>+1 (603)535-4592</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget">
                    <h5>Shuttle Service</h5>
                    <div class="widget-text">
                        <i class="lnr lnr-phone-handset"></i>
                        <p>+1 (603)535-4592</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget">
                    <h5>Restaurant</h5>
                    <div class="widget-text">
                        <i class="lnr lnr-phone-handset"></i>
                        <p>+1 (603)535-4592</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area">
        <div class="container">


        </div>
    </div>
</footer>
<!-- Footer Section End -->




<script src="jsHotel/main.js"></script>





</body>
</html>
<?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/master.blade.php ENDPATH**/ ?>
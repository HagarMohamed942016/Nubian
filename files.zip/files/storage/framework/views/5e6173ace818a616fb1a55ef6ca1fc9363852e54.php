<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Welcome Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <style>
        .body{
            background: url("img/boat.jpg");
            background-repeat: no-repeat;
        }

    </style>

</head>
<body>




    <div  class="body">


        <br><br>
    <div class="adminTables">

        &nbsp;&nbsp; <a class="btn btn-outline-info avatarAdmin" style="color:#fff;" href="/">Home</a>

    <?php if(auth()->user()->isAdmin()): ?>

        <br><br>


    <!-- <br><br> -->
        <!-- <a class="btn btn-info" href="/portfolioTable">Show Portfolios Table</a> -->
    <br><br>
         &nbsp;&nbsp;  <a class="btn btn-info" href="/roomTable">Show Room Table</a>
    <br><br>
        &nbsp;&nbsp; <a class="btn btn-info" href="/roomReservation">Show Room Reservation Table</a>
    <br><br>
        &nbsp;&nbsp;  <a class="btn btn-info" href="/restaurantTable">Show Restaurant Table</a>
    <br><br>
        &nbsp;&nbsp;  <a class="btn btn-info" href="/restaurantReservation">Show Restaurant Reservation Table</a>
    <br><br>
            &nbsp;

            <br><br>

<?php endif; ?>

        <br><br><br>
    </div>


    





    </div>


</body>
</html>
<?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/Admin/admin.blade.php ENDPATH**/ ?>
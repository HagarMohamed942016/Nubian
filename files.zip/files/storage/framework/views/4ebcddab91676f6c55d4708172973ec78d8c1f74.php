<?php $__env->startSection('content'); ?>

    <head>
        <title>Welcome To Our Hotel</title>
        <link rel="stylesheet" type="text/css" href="css/checkTable.css">
    </head>


    <div class="checkTable">

        <img src="imgRestaurant/food.jpg">
        <div class="loginbox">
            <img src="imgRestaurant/avatar.png" class="avatar">
            <h1>WELCOME</h1>
            <form action="/" method="post">
                <?php echo csrf_field(); ?>

                <br>

                <div class="row">
                    <div class="col-sm-6">
                        <p>Email</p>
                        <label><?php echo e($restaurant->email); ?></label>

                    </div>
                    <div class="col-sm-6">
                        <p>Phone</p>
                        <label><?php echo e($customer->phone); ?></label>

                    </div>
                </div>

                <br>

                <div class="row">

                    <div class="col-sm-6">
                        <p>Date</p>
                        <label><?php echo e($restaurant->date); ?></label>

                    </div>

                    <div class="col-sm-6">
                        <p>Time</p>
                        <label><?php echo e($restaurant->time); ?></label>

                    </div>

                </div>
                <br>
                <div class="row">

                    <div class="col-sm-6">
                        <p>Drinks</p>
                        <label><?php echo e($restaurant->Drinks); ?></label>
                        
                    </div>
                    <div class="col-sm-6">
                        <p>Foods</p>
                        <label><?php echo e($restaurant->Foods); ?></label>
                        
                    </div>

                </div>
                <br>

                <div class="row">

                    <div class="col-sm-6">
                        <p>Number Of Person</p>
                        <label><?php echo e($restaurant->No_of_person); ?></label>

                    </div>
                    <div class="col-sm-6">
                        <p>Total Price</p>
                        <label><?php echo e($restaurant->total_price); ?></label>

                    </div>

                </div>
                <br>

                <br>
                <div class="row">
                    <div class="col-sm-6">
                        <a class="btn btn-danger" href="/deleteReservationTable/<?php echo e($restaurant->id); ?>">Cancel</a>
                    </div>
                    <div class="col-sm-6">
                        <a href="/" class="btn btn-success">OK</a>
                    </div>
                </div>

            </form>

        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/checkRestaurant.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <p class="row mt-5">
            <p class="card" style="width: 50rem;">
                <p class="card-body">
                    <h5 class="card-title"> <?php echo e($product->product_name); ?><br></h5>
                    <p class="card-text">
                        <?php echo e($product->product_name); ?><br>
                        <div style="color: red;"><?php echo e($product->product_price); ?></div>
                    <?php echo e($product->product_description); ?>





        <br><br>
                      <a href="/products" class="btn btn-primary">return to Products</a>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/products/product.blade.php ENDPATH**/ ?>
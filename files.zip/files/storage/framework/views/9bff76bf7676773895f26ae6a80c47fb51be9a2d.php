<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link href="<?php echo e(asset('css')); ?>/test.css" rel="stylesheet">

        <link href="<?php echo e(asset('css')); ?>/app.css" rel="stylesheet">



        



</head>
<body>


<h1  class="title">Hagar</h1>

<form>

<div  class="form-group">
    <input type="text"  class="form-control">

</div>




</form>

<!-- 
                <div class="links">
                    <a href="/myname">Name</a>|
                    <a href="/myfather">Father</a>|
                    <a href="/mygrand">Grandfather</a>
                   
                </div> -->





</body>
</html>

   
<?php /**PATH C:\Laravel\blog\resources\views/person/hagar.blade.php ENDPATH**/ ?>
<?php echo e($product->product_name); ?>

<br>
<a  href="/delete/<?php echo e($product->id); ?>">Delete</a><?php /**PATH C:\Laravel\blog\resources\views/showProduct.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Room Table</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <br>
    <h2  style="color:blue">Room Table</h2>
    <br>
        <a class="btn btn-outline-info"   href="/createRoom">Create Room</a>
    <br><br>
    <table class="table  border-light">
        <thead class="thead-dark">
        <tr>




            <th>No Of Room</th>
            <th>Type of Room</th>
            <th>Price</th>

            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>


        </tr>
        </thead>
        
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>
                <td><?php echo e($room->No_of_room); ?></td>
                <td><?php echo e($room->type); ?></td>
                <td><?php echo e($room->Price); ?></td>






                <td><a class="btn btn-primary" href="/roomTable/<?php echo e($room->id); ?>">show</a></td>
                <td><a class="btn btn-success" href="/editRoom/<?php echo e($room->id); ?>">Edit</a></td>
                <td><a class="btn btn-danger" href="/deleteRoom/<?php echo e($room->id); ?>">Delete</a></td>


            </tr>
            </tbody>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </table>


</div>

</body>
</html>
<?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/Admin/roomTable.blade.php ENDPATH**/ ?>
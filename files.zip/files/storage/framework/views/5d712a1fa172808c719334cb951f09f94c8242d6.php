<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="card" style="width: 50rem;">
                <div class="card-body">
                    <h5 class="card-title"> <?php echo e('All products'); ?><br></h5>
                    <p class="card-text">
                    <form action="/products" method="Post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="product_name">Product Name</label>
                            <input type="text" class="form-control" name="product_name" id="product_name"
                                    placeholder="Enter Product Name">
                        </div>


                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Choose  category</label>
                            <select  class="form-control" id="category_id" name="category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option  value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class="form-group">
                            <label for="product_price">Product price</label>
                            <input type="text" class="form-control" name="product_price" id="product_price"
                                   placeholder="Enter Product price">
                        </div>
                        <div class="form-group form-check">
                            <label for="product_description">Product description</label>
                            <textarea type="text" class="form-control" name="product_description" id="product_description"
                                      placeholder="Enter Product description"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                        </p>
                        <a href="/products" class="btn btn-primary">Return to Products</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/products/createProduct.blade.php ENDPATH**/ ?>
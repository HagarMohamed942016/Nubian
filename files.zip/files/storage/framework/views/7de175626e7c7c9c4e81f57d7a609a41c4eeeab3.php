<!DOCTYPE html>
<html lang="en">
<head>
    <title>Room Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <br>
    <h2  style="color:blue">Room Reservation Table</h2>
    <br>

    <table class="table  border-light">
        <thead class="thead-dark">
        <tr>
            <th>Email</th>
            <th>Country</th>
            <th>Check In</th>
            <th>Check Out</th>
            <th>Type Of Room</th>
            <th>No Of Room</th>
            <th>Total Price</th>

        </tr>
        </thead>

        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
        <tr>
            <td><?php echo e($room->email); ?></td>
            <td><?php echo e($customer->country); ?></td>
            <td><?php echo e($room->check_in); ?></td>
            <td><?php echo e($room->check_out); ?></td>
            <td><?php echo e($room->type); ?></td>
            <td><?php echo e($room->No_of_room); ?></td>
            <td><?php echo e($room->total_price); ?></td>
        </tr>
            </tbody>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </table>


</div>

</body>
</html>
<?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/Admin/roomReservation.blade.php ENDPATH**/ ?>
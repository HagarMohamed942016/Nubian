<?php echo e($test); ?>

<?php /**PATH C:\Laravel\blog\resources\views/person/test.blade.php ENDPATH**/ ?>
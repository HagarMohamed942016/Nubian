<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

</head>
<body>

<h1>Mohamed</h1>

        <div class="links">
                    <a href="/myname">Name</a>|
                    <a href="/myfather">Father</a>|
                    <a href="/mygrand">Grandfather</a>
                   
        </div>






</body>
</html>

   
<?php /**PATH C:\Laravel\blog\resources\views/person/mohamed.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="card" style="width: 50rem;">
                <div class="card-body">
                    <h5 class="card-title"> <?php echo e('All products'); ?><br></h5>
                    <a href="/createproduct" class="btn btn-primary">Add new Product</a>
                    <p class="card-text">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($product->product_name); ?>

                            <a href="/products/<?php echo e($product->id); ?>" style="margin-left:20px;color: #6f42c1;">show</a>
                            <a href="/productedit/<?php echo e($product->id); ?>" style="margin-left:20px;color: #6f42c1;">Edit</a>
                            <a href="/productdelete/<?php echo e($product->id); ?>" style="margin-left:20px;color: #6f42c1;">Delete</a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <a href="#" class="btn btn-primary">Go somewhere</a>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/products/products.blade.php ENDPATH**/ ?>
<?php $__env->startSection('test'); ?>
Walaa
<?php $__env->stopSection(); ?>
<?php echo $__env->make('person.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/person/about.blade.php ENDPATH**/ ?>
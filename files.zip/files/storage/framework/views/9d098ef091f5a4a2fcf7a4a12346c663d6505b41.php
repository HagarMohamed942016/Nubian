<html>
<head>

</head>
<body>

<h1>Create New Product</h1>

<form  action="/"  method="Post">
    <?php echo csrf_field(); ?>
   <lebal>Product Name</label>
      <input type="text" name="product_name">
    <br>
    <lebal>Product Price</label>
      <input type="text" name="product_price">
    <br>
    <lebal>Product Description</label>
      <input type="text" name="product_description">
    <br>
    <input type="submit"  value="Add">

</form>




</body>
</html>
<?php /**PATH C:\Laravel\blog\resources\views/createProduct.blade.php ENDPATH**/ ?>
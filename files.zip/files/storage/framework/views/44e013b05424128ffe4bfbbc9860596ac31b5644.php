<!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Table</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <br>
    <h2  style="color:blue">Restaurant Table</h2>
    <br>
    <a class="btn btn-outline-info"   href="/createRestaurant">Create Table For Restaurant</a>
<br><br>
    <table class="table  border-light">
        <thead class="thead-dark">
        <tr>

            <th>Drinks</th>
            <th>Price of Drinks</th>
            <th>Foods</th>
            <th>Price of Foods</th>
            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>
        
        <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>

                <td><?php echo e($restaurant->Drinks); ?></td>
                <td><?php echo e($restaurant->Price_of_drinks); ?></td>
                <td><?php echo e($restaurant->Foods); ?></td>
                <td><?php echo e($restaurant->Price_of_foods); ?></td>
                <td><a class="btn btn-primary" href="/restaurantTable/<?php echo e($restaurant->id); ?>">show</a></td>
                <td><a class="btn btn-success" href="/editRestaurant/<?php echo e($restaurant->id); ?>">Edit</a></td>
                <td><a class="btn btn-danger" href="/deleteRestaurant/<?php echo e($restaurant->id); ?>">Delete</a></td>

                
                

            </tr>
            </tbody>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </table>


</div>

</body>
</html>
<?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/Admin/restaurantTable.blade.php ENDPATH**/ ?>
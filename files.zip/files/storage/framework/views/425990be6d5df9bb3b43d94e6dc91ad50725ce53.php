<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="card" style="width: 50rem;">
                <div class="card-body">
                    <h5 class="card-title"> <?php echo e('Edit products'); ?><br></h5>
                    <p class="card-text">
                    <form action="/productedit/<?php echo e($product->id); ?>/update" method="Post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="product_name">Product Name</label>
                            <input type="text" class="form-control" name="product_name"  value="<?php echo e($product->product_name); ?>" id="product_name"
                                    placeholder="Enter Product Name">
                        </div>
                        <div class="form-group">
                            <label for="product_price">Product price</label>
                            <input type="text" class="form-control" name="product_price"  value="<?php echo e($product->product_price); ?>" id="product_price"
                                   placeholder="Enter Product price">
                        </div>
                        <div class="form-group form-check">
                            <label for="product_description">Product description</label>
                            <textarea type="text" class="form-control" name="product_description" id="product_description"
                                      placeholder="Enter Product description"><?php echo e($product->product_description); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                        </p>
                        <a href="/products" class="btn btn-primary">Return to Products</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/products/editproduct.blade.php ENDPATH**/ ?>
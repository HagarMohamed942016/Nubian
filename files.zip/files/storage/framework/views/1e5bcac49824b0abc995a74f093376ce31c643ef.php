<?php $__env->startSection('content'); ?>


<head>
    <title>Welcome To Our Restaurant</title>
    <link rel="stylesheet" type="text/css" href="css/checkTable.css">
</head>


<div class="checkTable">
    <img src="imgJourney/abu-simbel1.jpg">
<div class="loginbox">
    <img src="imgRestaurant/avatar.png" class="avatar">
    <h1>WELCOME</h1>
    <form>

                <br>
                <p>Email</p>
                <label><?php echo e($reservation->email); ?></label>


                <div class="row">

                    <div class="col-sm-6">
                        <p>Check In</p>
                        <label><?php echo e($reservation->check_in); ?></label>

                    </div>

                    <div class="col-sm-6">
                        <p>Check Out</p>
                        <label><?php echo e($reservation->check_out); ?></label>

                    </div>

                </div>

                <div class="row">

                    <div class="col-sm-6">
                        <p>Type Of Room</p>
                        <label><?php echo e($reservation->type); ?></label>

                    </div>
                    <div class="col-sm-6">
                        <p>Number Of Room</p>
                        <label><?php echo e($reservation->No_of_room); ?></label>

                    </div>

                </div>

                <p>Total Price</p>
                <label><?php echo e($reservation->total_price); ?></label>




                <br>

        <a class="btn btn-danger" href="/deleteReservation/<?php echo e($reservation->id); ?>">Cancel</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a class="btn btn-primary" href="/index">OK</a>




            </form>


</div>
</div>











<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/checkRoom.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <br>
    <h2  style="color:blue">Restaurant Reservation Table</h2>
    <br>
    <table class="table  border-light">
        <thead class="thead-dark">
        <tr>
            <th>Email</th>
            <th>Phone</th>
            <th>Date</th>
            <th>Time</th>
            <th>No Of Person</th>
            <th>Drinks</th>
            <th>Foods</th>
            <th>Total Price</th>

        </tr>
        </thead>

        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
            <tr>
                <td><?php echo e($restaurant->email); ?></td>
                <td><?php echo e($customer->phone); ?></td>

                <td><?php echo e($restaurant->date); ?></td>
                <td><?php echo e($restaurant->time); ?></td>
                <td><?php echo e($restaurant->No_of_person); ?></td>
                <td><?php echo e($restaurant->Drinks); ?></td>
                <td><?php echo e($restaurant->Foods); ?></td>
                <td><?php echo e($restaurant->total_price); ?></td>

            </tr>
                        </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </table>


</div>

</body>
</html>
<?php /**PATH /home/hagarmohamed/Hagar/windows/VIP/Git/Project/resources/views/Admin/restaurantReservation.blade.php ENDPATH**/ ?>
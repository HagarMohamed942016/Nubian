<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
      

</head>
<body>


<h1>Hagar</h1>

<?php echo $__env->yieldContent('test'); ?>

</body>
</html>

   
<?php /**PATH C:\Laravel\blog\resources\views/person/master.blade.php ENDPATH**/ ?>